function validator(string, type, rules) {
	//check to see if valid input has been made on form
	
	//currently assume correct for now
	return true;
}