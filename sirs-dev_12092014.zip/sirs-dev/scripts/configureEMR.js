//this file, if we were to implement a true pull system
//would contain the code that would provide authentication and source of data for the CDS local service
//also it would where the local EMR IT staff would decide how the CDSS result would incarnate itself
//also it would be where the local staff would provide instructions for when the data pull should occur
//for the project the services are called by the EMR when data changes
//or Called by a timing function currently embedded in the EMR